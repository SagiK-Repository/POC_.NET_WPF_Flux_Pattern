﻿using DevExpress.Xpf.Core;

namespace Client
{
    public partial class MainWindow : ThemedWindow
    {
        public MainWindow()
        {
            InitializeComponent();
        }
    }
}
