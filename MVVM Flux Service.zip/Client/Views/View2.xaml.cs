﻿using Client.Domain.Interface.View;
using System.Windows;

namespace Client.Views
{
    public partial class View2 : Window, IView2Dialog
    {
        public View2()
        {
            InitializeComponent();
        }
    }
}
