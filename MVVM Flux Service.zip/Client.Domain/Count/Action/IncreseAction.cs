﻿namespace Client.Domain.Count.Action;
public class IncreseAction { }