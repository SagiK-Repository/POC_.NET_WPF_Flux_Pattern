﻿namespace Client.Domain.Interface.View;

public interface IView2Dialog
{
    void Show();
}
