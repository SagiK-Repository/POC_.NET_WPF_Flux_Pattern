﻿namespace Client.Domain.Interface.View;

public interface IView1Dialog
{
    void Show();
}
